<?php
    $hostname = 'localhost';
	$username = 'root';
	$password = '';
	$dbname   = 'galeryfoto';
	
	$conn = mysqli_connect($hostname, $username, $password, $dbname) or die ('galeryfoto');
?>